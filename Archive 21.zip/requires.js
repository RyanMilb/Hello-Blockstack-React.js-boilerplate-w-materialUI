if (typeof(window) !== 'undefined') {
  console.log('window.blockstack');
  window.blockstack = require('blockstack');
}
