# Hello-Blockstack-React.js-boilerplate-w-materialUI

This project is based on the [MERN-Boilerplate](https://github.com/keithweaver/MERN-boilerplate). It should help you get started with [Blockstack](https://blockstack.org/) as it shows how to integrate identity directly into your project. It is setup so that you can easily deploy to Heroku.


## Install Node Modules

```
npm install
```


## Run locally at http://localhost:5000

```
npm run start:dev
```

## Coming soon

```
Gaia storage Integration
```
